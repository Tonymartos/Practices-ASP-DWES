﻿Imports System.IO

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Dim j As Int16 = 1
            Dim linea As String
            Dim SR As StreamReader = New StreamReader(HttpContext.Current.Server.MapPath("~/") & "ejemplo.txt")

            Response.Clear()
            Response.ContentType = "text/plain"
            ' Content-Disposition campo de encabezado de respuesta  que se ha propuesto como un medio para que el 
            ' servidor de origen solicite al usuario si el contenido de respuesta se guarda en un archivo.
            ' Ver encabezados HTTP.
            Response.AppendHeader("content-disposition", "attachment; filename=resultado" + ".txt")
            While SR.Peek >= 0
                linea = SR.ReadLine()
                Response.Write(Space(3 - Len(j.ToString)) & j & ".- " & linea & vbCrLf)
                j += 1
            End While

            SR.Close()
        Catch ex As Exception
            Response.Write(ex.Message)
        Finally
            Response.End()
        End Try
    End Sub

End Class
