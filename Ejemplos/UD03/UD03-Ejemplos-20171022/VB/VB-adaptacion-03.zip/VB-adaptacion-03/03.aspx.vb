﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Comprobar
        Dim a As New SortedList(loto(6))

        ' Resultado en orden de aparición
        For i = 0 To a.Count - 1
            Response.Write(a.GetKey(a.IndexOfValue(i)) & "<br/>")
        Next

        Response.Write("________________________" & "<br/>")

        ' Resultado ordenados de menor a mayor
        For Each numero In a.GetKeyList
            Response.Write(numero & "<br/>")
        Next
    End Sub

    Public Function loto(ByVal t As Integer) As SortedList
        Dim l As New SortedList
        ' Organización de pares (clave,valor). Mantenida ordenada por claves
        ' claves:numeros loto, valores:orden de aparicion

        If t > 0 Then
            Dim i = 0, n As Integer
            Dim rnd As New Random()
            Do
                n = rnd.Next(1, 50)
                If Not l.ContainsKey(n) Then
                    l.Add(n, i)
                    i += 1
                End If
            Loop While i < t
        End If
        Return l
    End Function

End Class
