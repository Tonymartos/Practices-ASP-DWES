﻿Partial Class _Default
    Inherits System.Web.UI.Page

    Private Sub _Default_Load(sender As Object, e As EventArgs) Handles Me.Load

        ' También válido para ...
        ' Dim recuento As New ArrayList
        ' Aunque es preferible trabajar con una lista de objetos fuertemente tipada List(Of T)

        Dim recuento As New List(Of Votacion)
        recuento.Add(New Votacion With {.partido = "PSOE", .votos = 643244})
        recuento.Add(New Votacion With {.partido = "UPyD", .votos = 43110})
        recuento.Add(New Votacion With {.partido = "IU", .votos = 189265})
        recuento.Add(New Votacion With {.partido = "Podemos", .votos = 750607})
        recuento.Add(New Votacion With {.partido = "Ciudadanos", .votos = 676484})
        recuento.Add(New Votacion With {.partido = "PP", .votos = 1204059})

        recuento.Sort()

        For Each i In recuento
            Response.Write(i.partido & "-" & i.votos & "<br/>")
        Next

    End Sub
End Class

Public Structure Votacion
    Implements IComparable

    Public partido As String
    Public votos As Integer
    Public Function CompareTo(obj As Object) As Integer _
            Implements System.IComparable.CompareTo
        ' El objeto se convierte en la estructura votacion.
        Dim v As Votacion = DirectCast(obj, Votacion)
        ' Para ordenarlo descendentemente.
        If v.votos < Me.votos Then
            Return -1
        ElseIf Me.votos < v.votos Then
            Return 1
        Else
            Return 0
        End If
        ' Para ordenarlo ascendentemente, opción por defecto, utilizar:
        'Return Me.votos.CompareTo(v.votos)
    End Function
End Structure



