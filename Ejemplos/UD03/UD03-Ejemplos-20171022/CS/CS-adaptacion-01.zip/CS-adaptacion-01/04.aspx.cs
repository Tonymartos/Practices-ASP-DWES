﻿using System;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string frase = "hola";
        rotarI(ref frase,10);
        //rotarI(ref frase);
        //rotarI(ref frase);
        rotarI(ref frase);
        Response.Write(frase);
    }
    public void rotarI(ref string cadena,int veces)
    {
        for (int i = 1; i <= veces; i++) rotarI(ref cadena);
    }

    // Aunque el contenido de un string es inmutable, algunas formas de alterarlos ...

    //public void rotarI(ref string cadena)
    //{
    //    char[] nueva = cadena.ToCharArray(); // paso de string a char[]
    //    char aux = nueva[0];
    //    for (int i = 1; i < nueva.Length; i++) nueva[i - 1] = nueva[i];
    //    nueva[nueva.Length - 1] = aux;
    //    cadena = new string(nueva); // Paso de char[] a string
    //}

    //public void rotarI(ref string cadena) // Concatenando
    //{
    //    string nueva = "";
    //    char aux = cadena[0];
    //    for (int i = 1; i < cadena.Length; i++) nueva += cadena[i].ToString();
    //    cadena = nueva + aux;
    //}

    public void rotarI(ref string cadena) // Propiedades y métodos de la clase String (string)
    {
        cadena = cadena.Substring(1).PadRight(cadena.Length, cadena[0]);
    }
}