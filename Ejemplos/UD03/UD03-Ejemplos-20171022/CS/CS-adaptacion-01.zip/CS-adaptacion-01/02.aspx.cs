﻿using System;

public partial class _default: System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write(dias(2, 2012));
    }
    public sbyte dias(sbyte mes, short anio)
    {
        sbyte d = 0;
        if (mes>=1 && mes<=12)
        {
            switch(mes)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12: d= 31;break;
                case 4:
                case 6:
                case 9:
                case 11: d = 30;break;
                case 2:
                    if (anio % 4 == 0 && !(anio % 100 == 0 && anio % 400 != 0))
                    { d = 29;}
                    else
                    { d = 28;}
                    break;
            }
        }
        return d;
    }
}