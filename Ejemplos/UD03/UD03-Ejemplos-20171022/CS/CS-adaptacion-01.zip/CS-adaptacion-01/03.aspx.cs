﻿using System;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int[] a = { 4, 8, 9, 6, 1,3, 4, 0 };

        ordenar(ref a);

        foreach (int item in a)
        {
            Response.Write(item.ToString() + "<br/>");
        }
    }

    public void ordenar(ref int[] a) 
    {
        int s = a.GetLength(0);
        int i, j;
        for (i = s-1; i >0; i--)
        {
            for (j =0; j < i; j++)
            {
                if (a[j] > a[j + 1])
                {
                    // Conversión boxing. Para poder utilizar swap con object
                    object x = a[j]; 
                    object y = a[j + 1];

                    swap(ref x, ref y);
                    
                    // Conversión unboxing
                    a[j] = (int)x;
                    a[j+ 1] = (int)y;
                }
            }
        }
    }

    protected void swap(ref object x, ref object y)
    {
        object aux = x;
        x = y;
        y = aux;
    }

}