﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Int16 j = 1;
            string linea;
            System.IO.StreamReader SR = new StreamReader(HttpContext.Current.Server.MapPath("~/") + "ejemplo.txt");

            Response.Clear();
            Response.ContentType = "text/plain";
            // Content-Disposition campo de encabezado de respuesta  que se ha propuesto como un medio para que el 
            // servidor de origen solicite al usuario si el contenido de respuesta se guarda en un archivo.
            // Ver encabezados HTTP.
            Response.AppendHeader("content-disposition", "attachment; filename=resultado" + ".txt");
            while (SR.Peek() >= 0)
            {
                linea = SR.ReadLine();
                Response.Write(new String(' ',3 - j.ToString().Length) + j + ".- " + linea + "\r\n");
                j++;
            }

            SR.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            Response.End();
        }
    }
}