﻿using System;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        byte[,] p = { { 1, 6, 2 }, { 6, 2, 4 }, { 2, 4, 8 } };
        Response.Write(simetrica(p));
    }

    public bool simetrica(byte[,] A)
    {
        // Comprueba que una matriz es simétrica
        byte i, j;
        bool ok = false;

        byte m = (byte) A.GetLength(0);
        byte n = (byte) A.GetLength(1);

        // Tiene que ser cuadrada.
        if (m == n)
        {
            for (i = 0; i < m ; i++)
            {
                for (j = 0; j < n; j++)
                {
                    if (i != j)
                    {
                        if (A[i, j] != A[j, i])
                        {
                            goto salir; // Para salir de los dos bucles a la vez. Break solo sale de uno.
                        }
                    }
                }
            }
           ok=true;
        }
  salir:
        return ok;
    }

}