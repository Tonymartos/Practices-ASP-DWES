﻿using System;
using System.Net.Mail;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Ejemplo de llamada.
        //Se recuerda que una matriz de parámetros es declarada como opcional por defecto.

        enviaremail("godoyquilez@iesoretania.es", "Nuestro asunto", "Hola");

        enviaremail("godoyquilez@iesoretania.es", "Nuestro asunto", "Hola", @"archivos\A.txt", @"archivos\B.txt");
    }

    public void enviaremail(string direccion,string asunto, string mensaje, params string[] adjuntos)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(direccion, @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"))
        {
            throw new System.Exception("La dirección de correo no tiene el formato adecuado");
        }

        MailAddress origen = new MailAddress("iesoretania@gmail.com", "IES Oretania"); //' La cuenta de correo no tiene que ser la misma que es utilizada en el cliente SMTP
        MailAddress destino = new MailAddress(direccion);

        MailMessage email = new MailMessage(origen, destino);
        email.Subject = asunto;
        email.Body = mensaje;

        try
        {
            SmtpClient cliente = new SmtpClient("smtp.gmail.com");
            cliente.Credentials = new System.Net.NetworkCredential("iesoretania@gmail.com", "password");
            cliente.Port = 587;
            cliente.EnableSsl = true;

            if (adjuntos.Length!=0)
            {
                foreach(string archivo in adjuntos)
                {
                    //Suponemos que los archivos adjuntos existen y están ubicados en las carpeta especificadas. Esto implica que los parámetros se deben pasar convenientemente verificados.
                    email.Attachments.Add(new Attachment(archivo));
                }
            }
            cliente.Send(email);
        }
        catch (Exception ex)
        {
            throw new System.Exception(ex.Message);
        }
    }
}