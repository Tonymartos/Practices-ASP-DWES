﻿using System;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write(sentencia("26100100E", "García Sánchez, José", "953606060"));
        Response.Write("<br/>");
        Response.Write(sentencia("26100100E", "García Sánchez, José"));
    }

    public string sentencia(string nif,string nombre,string telefono=null)
    {
        System.Text.StringBuilder cadena = new System.Text.StringBuilder("insert into Alumnos values('<nif>','<nombre>',<telefono>)");
        cadena.Replace("<nif>", nif);
        cadena.Replace("<nombre>", nombre);
        cadena.Replace("<telefono>", (telefono != null) ?  "'" + telefono + "'" : "NULL");
        return cadena.ToString();
    }
}