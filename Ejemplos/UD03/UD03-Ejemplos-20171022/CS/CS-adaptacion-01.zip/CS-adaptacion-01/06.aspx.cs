﻿using System;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write(enorden("abcdefgh")); // No previsto las cadenas vacías.
    }

    public bool enorden(string palabra)
    {
        char anterior;
        bool ok = true;
        int i = 0;

        anterior = palabra[i++];
        while (i<palabra.Length )
        {
            if (palabra[i] < anterior)
            {
                ok = false;
                break;
            }
            anterior = palabra[i++];
        }
        return ok;
    }

}