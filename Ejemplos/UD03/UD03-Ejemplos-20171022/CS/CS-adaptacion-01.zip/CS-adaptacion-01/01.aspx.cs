﻿using System;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        object[] x = ec_2g( 1, -5, 6);
        Response.Write(x[0] + "<br/>");
        Response.Write(x[1] + "<br/>");
    }

    public object[] ec_2g(double a,double b,double c)
    {
        object[] x = new object[2];
        if (a==0)
        {
            x[0] = double.NaN;
            x[1] = double.NaN;
        }
        else
        {
            double D = Math.Pow(b, 2) - (4 * a * c);
            double t1 = -b / (2 * a);
            double t2 = Math.Sqrt(Math.Abs(D)) / (2 * a);
            if (D<0)
            {
                x[0] = t1 + "+" + t2 + " i";
                x[1] = t1 + "-" + t2 + " i";
            }
            else
            {
                x[0] = t1 + t2;
                x[1] = t1 - t2;
            }
        }
        return x;
    }

}