﻿using System;
using System.Collections;
using System.IO;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        foreach(string imagen in imgall(@"C:\Users\diego\Pictures"))
        {
            Response.Write(imagen + "<br/>");
        }
    }

    public ArrayList imgall(string carpeta)
    {
        string[] tipos = { ".JPG", ".JPEG", ".BMP", ".PNG", ".GIF" };
        ArrayList imgs=new ArrayList();

        if (Directory.Exists(carpeta))
        {
          DirectoryInfo pcontenedor = new DirectoryInfo(carpeta);
          FileInfo[] infocontenido = pcontenedor.GetFiles();
            foreach (FileInfo item in infocontenido)
            {
                if (Array.IndexOf(tipos,item.Extension.ToUpper())>=0) // Sin Linq (Contains)
                    imgs.Add(item.Name);
            }
        }
        return imgs;
    }

}