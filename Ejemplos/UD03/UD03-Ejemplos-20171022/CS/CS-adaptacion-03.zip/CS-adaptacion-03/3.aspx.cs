﻿using System;
using System.Collections;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Comprobar
        SortedList a = new SortedList(loto(6));

        // Resultado en orden de aparición
        for(int i=0;i< a.Count;i++)
        {
            Response.Write(a.GetKey(a.IndexOfValue(i)) + "<br/>");
        }

        Response.Write("________________________" + "<br/>");

        // Resultado ordenados de menor a mayor
        foreach(object numero in a.GetKeyList())
        {
            Response.Write(numero + "<br/>");
        }
    }

    public SortedList loto(int t)
    {
        SortedList l = new SortedList();
        // Organización de pares (clave,valor). Mantenida ordenada por claves
        // claves:numeros loto, valores:orden de aparicion
        if (t > 0)
        {
            int n, i = 0;
            Random rnd = new Random();
            do
            {
                n = rnd.Next(1, 50);
                if (!l.ContainsKey(n))
                {
                    l.Add(n, i++);
                }
            } while (i < t);
        }
        return l;
    }

}