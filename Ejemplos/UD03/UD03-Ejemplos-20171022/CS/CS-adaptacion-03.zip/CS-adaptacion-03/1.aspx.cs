﻿using System;
using System.Collections.Generic;

public partial class _default : System.Web.UI.Page
{
    protected Dictionary<string,decimal[]> hombre =new Dictionary<string,decimal[]> {{"20-29", new decimal[] { 0.83M, 0.88M, 0.94M}}, {"30-39", new decimal[] { 0.84M, 0.91M, 0.96M}}, {"40-49", new decimal[] { 0.88M, 0.95M, 1M}}, {"50-59", new decimal[] { 0.9M, 0.96M, 1.02M}}, {"60-69", new decimal[] { 0.91M, 0.98M, 1.03M}}};


    protected Dictionary<string, decimal[]> mujer = new Dictionary<string, decimal[]> { { "20-29", new decimal[] { 0.71M, 0.77M, 0.82M } }, { "30-39", new decimal[] { 0.72M, 0.78M, 0.84M } }, { "40-49", new decimal[] { 0.73M, 0.79M, 0.87M } }, { "50-59", new decimal[] { 0.74M, 0.81M, 0.88M } }, { "60-69", new decimal[] { 0.76M, 0.83M, 0.9M } } };

    protected void Page_Load(object sender, EventArgs e)
    {
        // Ejemplo de utilización:
        Response.Write(riesgo('M', 75M, 90M, "40-49") + "<br/>");
        Response.Write(riesgo('M', 0.67M, "40-49"));
    }

    public string riesgo (char sexo,decimal cintura,decimal cadera,string edad)
    {
        return riesgo(sexo, (cintura / cadera), edad);
    }

    public string riesgo(char sexo, decimal icc, string edad)
    {
        decimal[] tabla = (sexo == 'H') ? hombre[edad] : mujer[edad];
        string resultado = "";
        if (icc < tabla[0])
            { resultado = "Bajo."; }
        else if (icc >= tabla[0] && icc < tabla[1])
            { resultado = "Moderado."; }
        else if (icc >= tabla[1] && icc < tabla[2])
            { resultado = "Alto."; }
        else if(icc >= tabla[2])
            { resultado = "Muy alto."; }
        return resultado;
    }

}
