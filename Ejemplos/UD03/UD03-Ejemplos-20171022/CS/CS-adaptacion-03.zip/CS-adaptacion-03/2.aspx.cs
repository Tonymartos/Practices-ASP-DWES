﻿using System;
using System.Collections.Generic;

public partial class _default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // También válido para ...
        // ArrayList recuento=new ArrayList()
        // Aunque es preferible trabajar con una lista de objetos fuertemente tipada List<T>

        List<Votacion> recuento = new List<Votacion>();

        recuento.Add(new Votacion { partido = "PSOE", votos = 643244 });
        recuento.Add(new Votacion { partido = "UPyD", votos = 43110 });
        recuento.Add(new Votacion { partido = "IU", votos = 189265 });
        recuento.Add(new Votacion { partido = "Podemos", votos = 750607 });
        recuento.Add(new Votacion { partido = "Ciudadanos", votos = 676484 });
        recuento.Add(new Votacion { partido = "PP", votos = 1204059 });

        recuento.Sort();

        foreach (Votacion i in recuento)
        {
            Response.Write(i.partido + "-" + i.votos + "<br/>");
        }
    }
}


public struct Votacion : IComparable

{
    public string partido;
    public int votos;
    
    public int  CompareTo(object obj)
    {
        // El objeto se convierte en la estructura Votacion.
        Votacion v = (Votacion)obj;
        // Para ordenarlo descendentemente.
        if (v.votos < this.votos)
        {
            return -1;
        }
        else if (this.votos < v.votos)
        {
            return 1;
        }
        else
        {
            return 0;
        }
        //  Para ordenarlo ascendentemente, opción por defecto, utilizar:
        // return this.votos.CompareTo(v.votos);
    }

}
